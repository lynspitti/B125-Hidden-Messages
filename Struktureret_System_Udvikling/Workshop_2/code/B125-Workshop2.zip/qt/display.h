#ifndef DISPLAY_H
#define DISPLAY_H

#include <QMainWindow>

class Display_Handler {
    public:
    Display_Handler();
};

#endif // DISPLAY_H
