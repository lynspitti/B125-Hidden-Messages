#include "data_struckt.h"

Data_Struct::Data_Struct(int Value, int Type, unsigned long TimeStamp) {
  _Value = Value;
  _Type = Type;
  _TimeStamp = TimeStamp;
}
